package vectorejercicio;

import java.util.Scanner;

public class VectorEjercicio {

    public static void main(String[] args) {
        //Creacion de vector e ingreso de datos de nombre de tamano 10
        String[] nombres = new String[10];

        Scanner scanner = new Scanner(System.in);

        System.out.println("Por favor ingresa 10 nombres:");

        for (int i = 0; i < 10; i++) {
            System.out.print("Nombre " + (i + 1) + ": ");
            nombres[i] = scanner.nextLine();
        }

        System.out.println("Los nombres ingresados son:");
        for (String nombre : nombres) {
            System.out.println(nombre);
        }
        
        System.out.println("-------------------------------------------------");
        //Comparacion de cadenas de string con equals
        System.out.println("Comparacion de cadenas de STRING por medio de .equals ");
        
        //Se dejan ingresar por teclado las cadenas de String para despues compararlas
        System.out.println("Digite una cosa en la cadena uno ");
        String cadena1 = scanner.next(); 
        
        System.out.println("Digite otra cosa igual o diferente en la cadena dos ");
        String cadena2 = scanner.next();
        
        //Se comparan por medio de un condicional y el .equals que verifica si lo digitado en la cadena 1 es igual a lo que hay en la cadena 2
        //Si no muestre que son diferentes las cadenas
        if (cadena1.equals(cadena2)) {
            System.out.println("Las cadenas son iguales.");
        } else {
            System.out.println("Las cadenas son diferentes.");
        }
        
        System.out.println("--------------------------------------------------");
        
        System.out.println("Intercambio de datos de una variable a otra");
    
        int var1 = 2;
        int var2 = 600;
        
        //Se muestran los valores ya indicados para mostrar que si hay un intercambio
        System.out.println("Valores originales:");
        System.out.println("var1 = " + var1);
        System.out.println("var2 = " + var2);

        // Se crea una variable que nos ayude a pasar los datos sin borrarlo, una variable temporal
        //Guardara un dato mientras se pasa el dato a la variable que quedo clonada, una vez se pase el dato en temporal para a la otra variable
        int temporal = var1;
        var1 = var2;
        var2 = temporal;

        // Mostrar los datos después del intercambio
        System.out.println("\nDatos Intercambiados");
        System.out.println("var1 = " + var1);
        System.out.println("var2 = " + var2);
    }
}
